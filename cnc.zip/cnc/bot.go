package main

import (
	"net"
)

type Bot struct {
	uid    int
	conn   net.Conn
	source string
}

func NewBot(conn net.Conn, source string) *Bot {
	return &Bot{
		conn:   conn,
		source: source,
	}
}

func (b *Bot) QueueBuf(buf []byte) {
	b.conn.Write(buf) // Placeholder: change if needed
}
