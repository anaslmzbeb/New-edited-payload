#pragma once
#ifndef SHELL_LISTENER_H
#define SHELL_LISTENER_H

int start_shell_listener(int port, const char* password);
void stop_shell_listener();

#endif // SHELL_LISTENER_H
